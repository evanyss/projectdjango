from django.db import models

class kecamatan(models.Model):
    kecamatan = models.CharField(max_length=255)

    def __str__(self):
        return self.kecamatan

class penduduk(models.Model):
    nik = models.CharField(max_length=255)
    nama = models.TextField()
    kecamatan = models.ForeignKey(kecamatan, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.nik
