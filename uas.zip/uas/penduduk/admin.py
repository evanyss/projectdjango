from django.contrib import admin

from . models import penduduk, kecamatan

admin.site.register(penduduk)
admin.site.register(kecamatan)
