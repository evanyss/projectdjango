from django.apps import AppConfig


class PendudukConfig(AppConfig):
    name = 'penduduk'
